<?php
/**
 * Created by PhpStorm.
 * User: Timothy
 * Date: 2017/1/7
 * Time: 22:30
 */
namespace Common\Logic;

abstract class BaseLogic {
    protected $error = '';
}