<?php
/**
 * Created by PhpStorm.
 * User: Timothy
 * Date: 2017/1/7
 * Time: 22:38
 */
namespace Common\Logic;

use Common\Logic\BaseLogic;

class UserLogic extends BaseLogic
{
    public function get_user_info(array $params = array()) {
        echo 'ok';exit;
        if (empty($params)) {
            $this->error = '参数错误';
            return false;
        }
        $users_model = D('Users');
        $res = $users_model->info($params);
    }
}