<?php
/**
 * Created by PhpStorm.
 * User: Timothy
 * Date: 2017/1/5
 * Time: 21:22
 */
namespace Common\Controller;

use Think\Controller;

class BaseController extends Controller {

    protected function _initialize() {
        //languages('', 'common');
        defines();
    }
}