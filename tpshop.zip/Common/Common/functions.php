<?php
function defines() {
	// 当前网站url
	if(!defined('SITE_URL')) {
		define('SITE_URL', 'http://' . $_SERVER['SERVER_NAME'] . __ROOT__);
	}
	// 静态文件URL
	if(!defined('__STATIC__')) {
		define('__STATIC__', SITE_URL . '/statics');
	}
	// js静态文件URL
	if(!defined('__JS__')) {
		define('__JS__', __STATIC__ . '/js');
	}
    // echarts URL
    if(!defined('__ECHARTS__')) {
        define('__ECHARTS__', __STATIC__ . '/echarts');
    }
	// css静态文件URL
	if(!defined('__CSS__')) {
		define('__CSS__', __STATIC__ . '/css');
	}
	// 图片静态文件URL
	if(!defined('__IMAGE__')) {
		define('__IMAGE__', __STATIC__ . '/images');
	}
}
