<?php
/**
 * Created by PhpStorm.
 * User: Timothy
 * Date: 2017/1/7
 * Time: 23:05
 */

/**
 * @param string $name
 * @param string $type
 * @return Model|\Think\Model\
 */
function logic($name = '', $type = 'Logic') {
    return D($name, $type);
}

function dd($data) {
    dump($data);
    exit();
}