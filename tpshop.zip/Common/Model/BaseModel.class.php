<?php
/**
 * Created by PhpStorm.
 * User: Timothy
 * Date: 2017/1/7
 * Time: 22:11
 */
namespace Common\Model;

use Think\Model;

class BaseModel extends Model {
    protected $_error = '';

//    public function get_one() {
//        return $this->find();
//    }
}