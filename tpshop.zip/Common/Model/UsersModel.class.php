<?php
/**
 * Created by PhpStorm.
 * User: Timothy
 * Date: 2017/1/7
 * Time: 22:14
 */
namespace Common\Model;

use Common\Model\BaseModel;

class UsersModel extends BaseModel {

    /**
     * @desc 根据相应的条件获取用户的信息
     * @param array $params
     * @return array
     */
    public function info(array $params = array()) {
        if (empty($params)) {
            return $this->_error = '参数错误';
        }
        $where = array();
        if ($params['user_id']) {
            $where['user_id'] = $params['user_id'];
        }

        if ($params['user_name']) {
            $where['user_name'] = $params['user_name'];
        }

        if ($params['email']) {
            $where['email'] = $params['email'];
        }
        $res = $this->where($where)->find();
        return $res;
    }
}