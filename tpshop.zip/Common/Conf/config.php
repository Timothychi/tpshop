<?php
return array(
	//'配置项'=>'配置值'
    // 加载扩展配置文件
    'LOAD_EXT_CONFIG' => 'db',
    // 注册新的命名空间
    'AUTOLOAD_NAMESPACE' => array(
        'Common' => ROOT_PATH . 'Common'
    ),
    'TMPL_ENGINE_TYPE' => 'Smarty',
    'TMPL_TEMPLATE_SUFFIX' => '.html',
    'TMPL_ENGINE_CONFIG' => array(
        'caching' => false,
        'left_delimiter' => '<!--{',
        'right_delimiter' => '}-->'
    ),
    'LANG_SWITCH_ON' => true,
);