<?php
/**
 * Created by PhpStorm.
 * User: Timothy
 * Date: 2017/1/5
 * Time: 21:21
 */
namespace Home\Controller;

use Common\Controller\BaseController;

class UserController extends BaseController
{
    // 注册页面
    public function register() {
        $assign = self::lang();
        $this->assign($assign);
        $this->display();
    }

    public function captcha() {
        $config = array(
            'fontSize' => 15,    // 验证码字体大小
            'length' => 4,     // 验证码位数
            'useNoise' => false, // 关闭验证码杂点
        );
        $Verify = new \Think\Verify($config);
        $Verify->entry();
    }

    static private function lang() {
        $assign = array(
            'page_title' => L('page_title'),
            'reg_label_username' => L('reg_label_username'),
            'reg_label_email' => L('reg_label_email'),
            'reg_label_password' => L('reg_label_password'),
            'reg_label_confirm_password' => L('reg_label_confirm_password'),
            'reg_label_password_intensity' => L('reg_label_password_intensity'),
            'pwd_lower' => L('pwd_lower'),
            'pwd_middle' => L('pwd_middle'),
            'pwd_high' => L('pwd_high'),
            'reg_passwd_question' => L('reg_passwd_question'),
            'reg_sel_question' => L('reg_sel_question'),
            'reg_passwd_answer' => L('reg_passwd_answer'),
            'reg_comment_captcha' => L('reg_comment_captcha'),
            'want_login' => L('want_login'),
            'forgot_password' => L('forgot_password'),
            'reg_agreement' => L('reg_agreement'),

            'process_request' => L('reg_agreement'),

            'username_empty' => L('username_empty'),
            'username_invalid' => L('username_invalid'),
            'username_exist' => L('username_exist'),
            'username_not_allow' => L('username_exist'),
            'confirm_register' => L('confirm_register'),
            'process_request' => L('process_request'),
        );

        $assign['extend_info_list'] = array(
            'reg_label_qq' => L('reg_label_qq'),
            'reg_label_office_mobile' => L('reg_label_office_mobile'),
            'reg_label_family_mobile' => L('reg_label_family_mobile'),
            'reg_label_phone' => L('reg_label_phone'),
        );

        $assign['check_reg_info'] = array(
            'msg_un_blank' => L('msg_un_blank'),
            'msg_un_length' => L('msg_un_length'),
            'msg_un_format' => L('msg_un_format'),
            'msg_un_registered' => L('msg_un_registered'),
            'msg_can_rg' => L('msg_can_rg'),
            'msg_email_blank' => L('msg_email_blank'),
            'msg_email_registered' => L('msg_email_registered'),
            'msg_email_format' => L('msg_email_format'),
            'username_shorter' => L('username_shorter'),
            'username_invalid' => L('username_invalid'),
            'password_empty' => L('password_empty'),
            'password_shorter' => L('password_shorter'),
            'confirm_password_invalid' => L('confirm_password_invalid'),
            'email_empty' => L('email_empty'),
            'email_invalid' => L('email_invalid'),
            'agreement' => L('agreement'),
            'msn_invalid' => L('msn_invalid'),
            'qq_invalid' => L('qq_invalid'),
            'home_phone_invalid' => L('home_phone_invalid'),
            'office_phone_invalid' => L('office_phone_invalid'),
            'mobile_phone_invalid' => L('mobile_phone_invalid'),
            'msg_un_blank' => L('msg_un_blank'),
            'msg_un_length' => L('msg_un_length'),
            'msg_un_format' => L('msg_un_format'),
            'msg_un_registered' => L('msg_un_registered'),
            'msg_can_rg' => L('msg_can_rg'),
            'msg_email_blank' => L('msg_email_blank'),
            'msg_email_registered' => L('msg_email_registered'),
            'msg_email_format' => L('msg_email_format'),
            'msg_blank' => L('msg_blank'),
            'no_select_question' => L('no_select_question'),
            'passwd_balnk' => L('passwd_balnk'),
        );

        $assign['pass_questions'] = array(
            'friend_birthday' => L('friend_birthday'),
            'old_address' => L('old_address'),
            'motto' => L('motto'),
            'favorite_movie' => L('favorite_movie'),
            'favorite_song' => L('favorite_song'),
            'favorite_food' => L('favorite_food'),
            'interest' => L('interest'),
            'favorite_novel' => L('favorite_novel'),
            'favorite_equipe' => L('favorite_equipe'),
        );
        return $assign;
    }

    public function is_registered() {
        $users_model = null;
        $users_model = D('Users');
        $users_model = & $users_model;
        $user_name = I('username', '');
        $check = $users_model->info(array('user_name' => $user_name));
        unset($users_model);
        if (!$check) {
            $this->ajaxReturn(true);
        } else {
            $this->ajaxReturn(false);
        }
    }

    public function check_email() {
        $users_model = null;
        $users_model = D('Users');
        $users_model = & $users_model;
        $email = I('email', '');
        $check = $users_model->info(array('email' => $email));
        unset($users_model);
        if (!$check) {
            $this->ajaxReturn(true);
        } else {
            $this->ajaxReturn(false);
        }
    }

    public function do_register() {
        $users_model = null;
        $users_model = D('Users');
        $users_model = & $users_model;
        dd(I());
        $params = array(
            'username' => I('username', ''),
            'email' => I('email', ''),
            'email' => I('email', ''),
            'email' => I('email', ''),
            'email' => I('email', ''),
            'email' => I('email', ''),
            'email' => I('email', ''),
        );
        $data = $this->_filter_data($params);
        $check = $users_model->info(array('email' => $email));
        unset($users_model);
        if (!$check) {
            $this->ajaxReturn(true);
        } else {
            $this->ajaxReturn(false);
        }
    }

    private function _filter_data(array $data = array()) {
        if (empty($data)) {
            return array();
        }

    }

    public function test() {
        $user_logic = logic('Users');
        $res = $user_logic->get_user_info();
    }
}