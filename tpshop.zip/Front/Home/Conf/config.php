<?php
return array(
	//'配置项'=>'配置值'
    'VIEW_PATH' => TPL_PATH . MODULE_NAME . DIRECTORY_SEPARATOR,
    'TMPL_FILE_DEPR' => '_',
);