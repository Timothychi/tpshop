<?php

// 绑定Rest模块
define('APP_NAME','Admin');

// 引入ThinkPHP入口文件
require './common.php';

// 亲^_^ 后面不需要任何代码了 就是如此简单
