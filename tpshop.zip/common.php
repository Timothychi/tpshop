<?php
// +----------------------------------------------------------------------
// | ThinkPHP [ WE CAN DO IT JUST THINK ]
// +----------------------------------------------------------------------
// | Copyright (c) 2006-2014 http://thinkphp.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: liu21st <liu21st@gmail.com>
// +----------------------------------------------------------------------

// 应用入口文件

// 检测PHP环境
if (version_compare(PHP_VERSION, '5.3.0', '<')) {
    die('require PHP > 5.3.0 !');
}

// 开启调试模式 建议开发阶段开启 部署阶段注释或者设为false
define('APP_DEBUG', true);

// 物理根路径
define('ROOT_PATH', rtrim(dirname(__FILE__), '/\\') . DIRECTORY_SEPARATOR);

// 定义应用目录
define('APP_PATH', ROOT_PATH . './' . APP_NAME . '/');

// 定义公共目录
define('COMMON_PATH', ROOT_PATH . './Common/');

// 定义Runtime目录
define('RUNTIME_PATH', ROOT_PATH . './Runtime/');

// 模板缓存目录
define('CACHE_PATH', ROOT_PATH . './Cache/' . APP_NAME . '/');

// 定义Logs目录
define('LOG_PATH', ROOT_PATH . './Logs/' . APP_NAME . '/');

// 定义模板目录
define('TPL_PATH', ROOT_PATH . './Template/' . APP_NAME . '/');

// 定义插件目录
define('PLUGIN_PATH', COMMON_PATH . 'Plugin/');
// 绑定Rest模块
define('BIND_MODULE','Home');

// 引入公共文件
require_once COMMON_PATH . 'Common/functions.php';

// 引入ThinkPHP入口文件
require './ThinkPHP/ThinkPHP.php';

// 亲^_^ 后面不需要任何代码了 就是如此简单
